import React from 'react';
import CartItems from '../components/cartItems/CartItems';

function ShoppingCart () {
    return (
        <div>
            <CartItems/>
        </div>
    )
}

export default ShoppingCart